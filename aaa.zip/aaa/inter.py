import os
import pandas as pd
import hashlib
import csv  # Ajoutez cette ligne pour importer le module csv
import tkinter as tk
from tkinter import messagebox
from modules.auth import *
# from modules.gestion_commercant import *
from modules.gestion_produits import *
def menu_modif(username, password):
    # Crée une nouvelle fenêtre de modification
    modif_frame = tk.Frame(root, bg="#f4f4f4")  
    modif_frame.pack(fill=tk.BOTH, expand=True)

    # Titre pour la modification
    title_label = tk.Label(modif_frame, text="Modifier vos informations", font=("Helvetica", 16, 'bold'), fg="#2e2e2e", bg="#f4f4f4")
    title_label.pack(pady=20)

    # Champ pour modifier le nom d'utilisateur
    tk.Label(modif_frame, text="Nom d'utilisateur:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    username_entry = tk.Entry(modif_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, bg="#eaeaea")
    username_entry.insert(0, username)  # Affiche le nom d'utilisateur actuel
    username_entry.pack(pady=5)

    # Champ pour modifier le mot de passe
    tk.Label(modif_frame, text="Mot de passe:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    password_entry = tk.Entry(modif_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, show="*", bg="#eaeaea")
    password_entry.insert(0, password)  # Affiche le mot de passe actuel
    password_entry.pack(pady=5)

    def handle_modification():
        new_username = username_entry.get()
        new_password = password_entry.get()

        if not new_username or not new_password:
            messagebox.showerror("Erreur", "Tous les champs doivent être remplis.")
            return

        # Mettez ici la logique de modification (exemple : mise à jour dans un fichier CSV ou base de données)
        # Cette partie peut être personnalisée en fonction de votre structure de données
        # Par exemple, vous pouvez appeler une fonction qui met à jour les données de l'utilisateur

        # Confirmation de la modification
        messagebox.showinfo("Succès", "Vos informations ont été modifiées avec succès!")
        modif_frame.destroy()  # Fermer le cadre de modification
        menu_user(username)  # Retour au menu utilisateur

    # Bouton pour valider la modification
    btn_modify = tk.Button(modif_frame, text="Valider la modification", font=("Helvetica", 12), command=handle_modification, bg="#4a90e2", fg="white", relief="flat")
    btn_modify.pack(pady=20)

    # Fonction pour revenir en arrière
    def go_back():
        modif_frame.destroy()
        menu_user(username)

    # Bouton pour revenir en arrière
    btn_back = tk.Button(modif_frame, text="Retour", font=("Helvetica", 12), command=go_back, bg="#7f8c8d", fg="white", relief="flat")
    btn_back.pack(pady=10)

def inscription():
    clear_frame()  # On vide l'écran actuel pour afficher le formulaire d'inscription

    # Créer une nouvelle fenêtre pour l'inscription
    inscription_frame = tk.Frame(root, bg="#f4f4f4")  # Fond gris clair
    inscription_frame.pack(fill=tk.BOTH, expand=True)

    # Ajouter un titre
    title_label = tk.Label(inscription_frame, text="Formulaire d'Inscription", font=("Helvetica", 16, 'bold'), fg="#2e2e2e", bg="#f4f4f4")  # Gris foncé pour le texte
    title_label.pack(pady=20)

    # Champ pour le numéro d'identifiant
    tk.Label(inscription_frame, text="Numéro d'identifiant:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    id_entry = tk.Entry(inscription_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, bg="#eaeaea")  # Fond gris clair pour le champ
    id_entry.pack(pady=5)

    # Champ pour le nom
    tk.Label(inscription_frame, text="Nom:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    nom_entry = tk.Entry(inscription_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, bg="#eaeaea")
    nom_entry.pack(pady=5)

    # Champ pour le nom d'utilisateur
    tk.Label(inscription_frame, text="Nom d'utilisateur:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    username_entry = tk.Entry(inscription_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, bg="#eaeaea")
    username_entry.pack(pady=5)

    # Champ pour l'adresse mail
    tk.Label(inscription_frame, text="Adresse mail:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    mail_entry = tk.Entry(inscription_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, bg="#eaeaea")
    mail_entry.pack(pady=5)

    # Champ pour le mot de passe
    tk.Label(inscription_frame, text="Mot de passe:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    password_entry = tk.Entry(inscription_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, show="*", bg="#eaeaea")
    password_entry.pack(pady=5)

    def verif_mdp(password):
        return len(password) < 8  # Vérification de la longueur du mot de passe

    def handle_inscription():
        # Récupérer les valeurs des champs
        id_user = id_entry.get()
        nom_user = nom_entry.get()
        username_user = username_entry.get()
        mail_user = mail_entry.get()
        password_user = password_entry.get()

        # Vérification du mot de passe
        if verif_mdp(password_user):
            messagebox.showerror("Erreur", "Le mot de passe doit contenir au moins 8 caractères.")
            return

        # Génération du salage (salt)
        salt = os.urandom(16).hex()

        # Combinaison du mot de passe et du salt, puis hachage
        salted_password = salt + password_user
        password_hash = hashlib.sha256(salted_password.encode()).hexdigest()

        # Vérifier si le fichier existe déjà
        file_path = 'data_user.csv'
        
        # Si le fichier n'existe pas, créer et ajouter l'en-tête
        if not os.path.exists(file_path):
            with open(file_path, mode='w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["ID", "Adresse mail", "Nom", "Username", "Password", "Salt"])

        # Ajouter les données utilisateur dans le fichier CSV
        with open(file_path, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([id_user, mail_user, nom_user, username_user, password_hash, salt])

        # Afficher un message de confirmation
        messagebox.showinfo("Succès", "Inscription réussie!")

    # Fonction pour revenir à la page principale et fermer la fenêtre d'inscription
    def go_back():
        inscription_frame.destroy()  # Fermer le frame actuel d'inscription
        menu_gui()  # Appel à la fonction pour afficher la page d'accueil ou le menu principal

    # Bouton pour soumettre l'inscription avec un style
    btn_submit = tk.Button(inscription_frame, text="S'inscrire", font=("Helvetica", 12), bg="#4a90e2", fg="white", relief="flat", width=20, height=2, command=handle_inscription)
    btn_submit.pack(pady=20)

    # Bouton pour revenir en arrière (page principale) avec un style
    btn_back = tk.Button(inscription_frame, text="Retour", font=("Helvetica", 12), bg="#7f8c8d", fg="white", relief="flat", width=20, height=2, command=go_back)
    btn_back.pack(pady=10)
    
    
    
    
    
    
    
def create(username):
    clear_frame()  # On vide l'écran actuel pour afficher le menu utilisateur

    folder_path = 'data'  # Dossier 'data'
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)  # Crée le dossier 'data' s'il n'existe pas

    txt = os.path.join(folder_path, f'{username}.csv')  # Création du chemin complet vers le fichier
    if not os.path.exists(txt):
        # Crée un DataFrame vide et enregistre le fichier CSV
        df = pd.DataFrame(columns=["ID", "Nom", "Prix (EUR)"])
        df.to_csv(txt, index=False)
        messagebox.showinfo("Succès", f"Le fichier '{txt}' a été créé.")
    else:
        messagebox.showinfo("Info", f"Le fichier '{txt}' existe déjà.")


def supprimer(username):
    clear_frame()  # On vide l'écran actuel pour afficher le menu utilisateur

    folder_path = 'data'  # Dossier 'data'
    txt = os.path.join(folder_path, f'{username}.csv')  # Création du chemin complet vers le fichier

    if os.path.exists(txt):
        os.remove(txt)
        messagebox.showinfo("Succès", f"Le fichier '{txt}' a été supprimé.")
    else:
        messagebox.showerror("Erreur", f"Le fichier '{txt}' n'existe pas.")


def afficher(username):
    clear_frame()  # On vide l'écran actuel pour afficher le menu utilisateur

    folder_path = 'data'  # Le dossier où se trouvent les fichiers CSV
    txt = os.path.join(folder_path, f'{username}.csv')  # Construire le chemin complet du fichier

    if os.path.exists(txt):  # Vérifier si le fichier existe
        try:
            df = pd.read_csv(txt)  # Tenter de lire le fichier CSV

            if df.empty:
                messagebox.showinfo("Info", f"Le fichier '{txt}' est vide.")
            else:
                messagebox.showinfo("Affichage", f"Contenu du fichier '{txt}':\n{df}")
        except pd.errors.EmptyDataError:
            messagebox.showerror("Erreur", f"Le fichier '{txt}' est vide ou mal formaté.")
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la lecture du fichier '{txt}': {e}")
    else:
        messagebox.showerror("Erreur", f"Le fichier '{txt}' n'existe pas.")


# Fonction pour rechercher un produit dans un fichier CSV
def rechercher_sequ(username, frame):
    def clear_frame():
        for widget in frame.winfo_children():
            widget.destroy()

    def perform_search():
        folder_path = 'data'
        txt = os.path.join(folder_path, f'{username}.csv')

        if os.path.exists(txt):
            try:
                df = pd.read_csv(txt)

                if 'Nom' not in df.columns:
                    messagebox.showerror("Erreur", f"La colonne 'Nom' est introuvable dans le fichier '{txt}'.")
                    return

                recherche = entry_recherche.get().strip().lower()

                if not recherche:
                    messagebox.showerror("Erreur", "Vous devez entrer un nom de produit.")
                    return

                # Recherche de produits qui contiennent la chaîne de recherche (insensible à la casse)
                df_filtered = df[df['Nom'].str.contains(recherche, case=False, na=False)]

                # Vérifier si des produits ont été trouvés et afficher les résultats
                if not df_filtered.empty:
                    messagebox.showinfo("Résultat", f"Produit(s) trouvé(s) :\n{df_filtered}")
                else:
                    messagebox.showinfo("Résultat", f"Aucun produit ne correspond à '{recherche}'.")
            except pd.errors.EmptyDataError:
                messagebox.showerror("Erreur", f"Le fichier '{txt}' est vide ou mal formaté.")
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur lors de la lecture ou de la recherche dans le fichier '{txt}': {e}")
        else:
            messagebox.showerror("Erreur", f"Le fichier '{txt}' n'existe pas.")

    clear_frame()

    # Ajout du champ de recherche et du bouton
    label_recherche = tk.Label(frame, text="Entrez le nom du produit à rechercher :")
    label_recherche.pack(pady=10)

    entry_recherche = tk.Entry(frame)
    entry_recherche.pack(pady=10)

    search_button = tk.Button(frame, text="Rechercher", command=perform_search)
    search_button.pack(pady=10)

def tri_bul(username, frame):
    def clear_frame():
        for widget in frame.winfo_children():
            widget.destroy()

    def perform_sort():
        folder_path = 'data'
        file_path = os.path.join(folder_path, f'{username}.csv')

        if os.path.exists(file_path):
            try:
                df = pd.read_csv(file_path)
                if 'Nom' not in df.columns:
                    messagebox.showerror("Erreur", f"La colonne 'Nom' est introuvable dans le fichier '{file_path}'.")
                    return

                # Tri des produits par le nom
                df_sorted = df.sort_values(by="Nom")

                messagebox.showinfo("Résultat", f"Produits triés par nom :\n{df_sorted}")

                # Sauvegarder les changements dans le fichier CSV
                df_sorted.to_csv(file_path, index=False)
                messagebox.showinfo("Succès", "Les produits ont été triés et enregistrés.")
            except Exception as e:
                messagebox.showerror("Erreur", f"Erreur lors du tri des produits dans le fichier '{file_path}': {e}")
        else:
            messagebox.showerror("Erreur", f"Le fichier '{file_path}' n'existe pas.")

    clear_frame()

    sort_button = tk.Button(frame, text="Trier les produits par nom", command=perform_sort)
    sort_button.pack(pady=10)

def create_interface(username):
    global frame

    root = tk.Tk()
    root.title("Gestion des Produits")

    frame = tk.Frame(root)
    frame.pack(padx=20, pady=20)

    # Boutons pour la recherche et le tri
    search_button = tk.Button(frame, text="Rechercher un produit", command=lambda: rechercher_sequ(username))
    search_button.pack(pady=10)

    sort_button = tk.Button(frame, text="Trier les produits", command=lambda: tri_bul(username))
    sort_button.pack(pady=10)

    root.mainloop()
import tkinter as tk

def menu_user(username):
    clear_frame() 

    # Créer une nouvelle fenêtre pour le menu utilisateur
    menu_user_frame = tk.Frame(root, bg="#ffffff")  # Fond de la fenêtre avec une couleur douce
    menu_user_frame.pack(fill=tk.BOTH, expand=True)

    # Titre avec fond sombre et texte clair
    label_title = tk.Label(menu_user_frame, text=f"Menu de {username}", font=("Helvetica", 20), fg="black")
    label_title.pack(pady=40)

    # Boutons avec des couleurs douces et effets au survol
    button_bg = "#5A9EC9"  # Bleu doux pour les boutons
    button_fg = "white"     # Texte en blanc pour contrasters
    button_hover_bg = "#4A8BBE"  # Couleur au survol, plus foncée

    # Fonction pour changer la couleur au survol
    def on_enter(e):
        e.widget['background'] = button_hover_bg

    def on_leave(e):
        e.widget['background'] = button_bg

    # Créer les boutons
    btn_create = tk.Button(menu_user_frame, text="Créer un fichier", font=("Helvetica", 12), command=lambda: create(username), bg=button_bg, fg=button_fg, relief="flat")
    btn_create.pack(pady=10, fill=tk.X, padx=50)
    btn_create.bind("<Enter>", on_enter)
    btn_create.bind("<Leave>", on_leave)

    btn_delete = tk.Button(menu_user_frame, text="Supprimer un fichier", font=("Helvetica", 12), command=lambda: supprimer(username), bg=button_bg, fg=button_fg, relief="flat")
    btn_delete.pack(pady=10, fill=tk.X, padx=50)
    btn_delete.bind("<Enter>", on_enter)
    btn_delete.bind("<Leave>", on_leave)

    btn_display = tk.Button(menu_user_frame, text="Afficher un fichier", font=("Helvetica", 12), command=lambda: afficher(username), bg=button_bg, fg=button_fg, relief="flat")
    btn_display.pack(pady=10, fill=tk.X, padx=50)
    btn_display.bind("<Enter>", on_enter)
    btn_display.bind("<Leave>", on_leave)

    btn_add_product = tk.Button(menu_user_frame, text="Ajouter un produit", font=("Helvetica", 12), command=lambda: ajouter_produit(username), bg=button_bg, fg=button_fg, relief="flat")
    btn_add_product.pack(pady=10, fill=tk.X, padx=50)
    btn_add_product.bind("<Enter>", on_enter)
    btn_add_product.bind("<Leave>", on_leave)

    btn_search = tk.Button(menu_user_frame, text="Rechercher un produit", font=("Helvetica", 12), command=lambda: rechercher_sequ(username, menu_user_frame), bg=button_bg, fg=button_fg, relief="flat")
    btn_search.pack(pady=10, fill=tk.X, padx=50)
    btn_search.bind("<Enter>", on_enter)
    btn_search.bind("<Leave>", on_leave)

    btn_search = tk.Button(menu_user_frame, text="Trier les produits", font=("Helvetica", 12), command=lambda: tri_bul(username, menu_user_frame), bg=button_bg, fg=button_fg, relief="flat")
    btn_search.pack(pady=10, fill=tk.X, padx=50)
    btn_search.bind("<Enter>", on_enter)
    btn_search.bind("<Leave>", on_leave)

    btn_logout = tk.Button(menu_user_frame, text="Se déconnecter", font=("Helvetica", 12), command=open_connexion_window, bg=button_bg, fg=button_fg, relief="flat")
    btn_logout.pack(pady=10, fill=tk.X, padx=50)
    btn_logout.bind("<Enter>", on_enter)
    btn_logout.bind("<Leave>", on_leave)


def ajouter_produit(username):
    clear_frame()  # On vide l'écran actuel pour afficher le menu utilisateur

    add_product_window = tk.Frame(root)
    add_product_window.pack(fill=tk.BOTH, expand=True)

    tk.Label(add_product_window, text="Nom du produit:", font=("Helvetica", 12)).pack(pady=10)
    product_name_entry = tk.Entry(add_product_window, font=("Helvetica", 12), fg="black")
    product_name_entry.pack(pady=5)

    tk.Label(add_product_window, text="Prix du produit (EUR):", font=("Helvetica", 12)).pack(pady=10)
    product_price_entry = tk.Entry(add_product_window, font=("Helvetica", 12), fg="black")
    product_price_entry.pack(pady=5)

    def handle_add_product():
        # Récupérer les valeurs des champs
        product_name = product_name_entry.get()
        product_price = product_price_entry.get()

        if not product_name or not product_price:
            messagebox.showerror("Erreur", "Tous les champs doivent être remplis.")
            return

        try:
            # Vérification si le prix est valide
            product_price = float(product_price)
        except ValueError:
            messagebox.showerror("Erreur", "Le prix doit être un nombre valide.")
            return

        # Ouvrir le fichier CSV correspondant à l'utilisateur (avec le username + ".csv")
        file_path = os.path.join('data', f'{username}.csv')

        if not os.path.exists(file_path):
            # Si le fichier n'existe pas, on le crée
            df = pd.DataFrame(columns=["ID", "Nom", "Prix (EUR)"])
            df.to_csv(file_path, index=False)
            messagebox.showinfo("Info", "Le fichier produit a été créé.")

        # Lire le fichier CSV existant
        try:
            df = pd.read_csv(file_path)

            # Ajout du nouveau produit
            new_product_id = len(df) + 1  # Création d'un ID unique pour chaque produit
            new_product = pd.DataFrame([[new_product_id, product_name, product_price]], columns=["ID", "Nom", "Prix (EUR)"])
            df = pd.concat([df, new_product], ignore_index=True)

            # Sauvegarder les changements dans le fichier
            df.to_csv(file_path, index=False)
            messagebox.showinfo("Succès", "Produit ajouté avec succès!")

            # Nettoyer les champs après l'ajout
            product_name_entry.delete(0, tk.END)
            product_price_entry.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Erreur", f"Une erreur est survenue lors de l'ajout du produit : {e}")

    # Bouton pour valider l'ajout du produit
    btn_add_product_submit = tk.Button(add_product_window, text="Ajouter le produit", font=("Helvetica", 12), command=handle_add_product)
    btn_add_product_submit.pack(pady=20)
def go_back():
    menu_gui()
def open_connexion_window():
    clear_frame()

    # Créer une nouvelle fenêtre pour la connexion
    login_frame = tk.Frame(root)
    login_frame.pack(fill=tk.BOTH, expand=True)

    tk.Label(login_frame, text="Nom d'utilisateur", font=("Helvetica", 12), fg="grey", bg="#000000").pack(pady=10)
    username_entry = tk.Entry(login_frame, font=("Helvetica", 12), fg="black")
    username_entry.pack(pady=5, fill=tk.X, padx=50)

    tk.Label(login_frame, text="Mot de passe", font=("Helvetica", 12), fg="grey", bg="#000000").pack(pady=10)
    password_entry = tk.Entry(login_frame, font=("Helvetica", 12), fg="black", show="*")
    password_entry.pack(pady=5, fill=tk.X, padx=50)

    def handle_login():
        username = username_entry.get()
        password = password_entry.get()
        print(f"Connexion de {username}...")  # Ajouter la logique de validation ici
        # Appel à la fonction menu_user après connexion réussie
        menu_user(username)
    btn_back = tk.Button(login_frame, text="Retour", font=("Helvetica", 12), fg="white", bg="#808080", relief="flat", height=2, command=go_back)
    btn_back.pack(pady=10, fill=tk.X, padx=50)
    # Bouton pour la connexion
    btn_login = tk.Button(login_frame, text="Se connecter", font=("Helvetica", 12), fg="white", bg="#000000", relief="flat", height=2, command=handle_login)
    btn_login.pack(pady=20, fill=tk.X, padx=50)


# Fonction pour nettoyer l'écran
def clear_frame():
    for widget in root.winfo_children():
        widget.destroy()

def menu_modif(username, password):
    # Crée une nouvelle fenêtre de modification
    modif_frame = tk.Frame(root, bg="#f4f4f4")
    modif_frame.pack(fill=tk.BOTH, expand=True)

    # Titre pour la modification
    title_label = tk.Label(modif_frame, text="Modifier vos informations", font=("Helvetica", 16, 'bold'), fg="#2e2e2e", bg="#f4f4f4")
    title_label.pack(pady=20)

    # Champ pour modifier le nom d'utilisateur
    tk.Label(modif_frame, text="Nom d'utilisateur:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    username_entry = tk.Entry(modif_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, bg="#eaeaea")
    username_entry.insert(0, username)  # Affiche le nom d'utilisateur actuel
    username_entry.pack(pady=5)

    # Champ pour modifier le mot de passe
    tk.Label(modif_frame, text="Mot de passe:", font=("Helvetica", 12), bg="#f4f4f4", fg="#5a5a5a").pack(pady=10)
    password_entry = tk.Entry(modif_frame, font=("Helvetica", 12), fg="black", relief="solid", bd=1, width=30, show="*", bg="#eaeaea")
    password_entry.insert(0, password)  # Affiche le mot de passe actuel
    password_entry.pack(pady=5)

    def handle_modification():
        new_username = username_entry.get()
        new_password = password_entry.get()

        if not new_username or not new_password:
            messagebox.showerror("Erreur", "Tous les champs doivent être remplis.")
            return

        # Mettez ici la logique de modification (exemple : mise à jour dans un fichier CSV ou base de données)
        # Cette partie peut être personnalisée en fonction de votre structure de données
        # Par exemple, vous pouvez appeler une fonction qui met à jour les données de l'utilisateur

        # Confirmation de la modification
        messagebox.showinfo("Succès", "Vos informations ont été modifiées avec succès!")
        modif_frame.destroy()  # Fermer le cadre de modification
        menu_user(username)  # Retour au menu utilisateur

    # Bouton pour valider la modification
    btn_modify = tk.Button(modif_frame, text="Valider la modification", font=("Helvetica", 12), command=handle_modification, bg="#4a90e2", fg="white", relief="flat")
    btn_modify.pack(pady=20)

    # Fonction pour revenir en arrière
    def go_back():
        modif_frame.destroy()
        menu_user(username)

    # Bouton pour revenir en arrière
    btn_back = tk.Button(modif_frame, text="Retour", font=("Helvetica", 12), command=go_back, bg="#7f8c8d", fg="white", relief="flat")
    btn_back.pack(pady=10)

    
# Fonction principale de l'interface graphhique
import tkinter as tk

# Fonction pour le menu principal
import tkinter as tk

import tkinter as tk

def menu_gui():
    global root
    root = tk.Tk()
    root.title("Menu Principal")
    root.geometry("700x550")
    root.config(bg="#e9f1f7")  # Fond de la fenêtre gris clair

    # Créer un cadre pour le menu
    menu_frame = tk.Frame(root, bg="#f4f4f4")  # Fond clair pour la fenêtre
    menu_frame.pack(fill=tk.BOTH, expand=True)

    # Titre avec texte sombre
    label_title = tk.Label(menu_frame, text="Bienvenue", font=("Helvetica", 20), fg="black", bg="#f4f4f4")
    label_title.pack(pady=40)

    # Sous-titre
    label_subtitle = tk.Label(menu_frame, text="Sélectionnez une option", font=("Helvetica", 12), fg="#2e2e2e", bg="#f4f4f4")
    label_subtitle.pack(pady=10)

    # Définir les couleurs pour les boutons
    button_bg = "#000000"  # Couleur de fond des boutons (noir)
    button_fg = "white"    # Texte des boutons en blanc
    button_hover_bg = "#808080"  # Couleur plus foncée au survol

    # Fonction pour changer la couleur du bouton au survol
    def on_enter(e):
        e.widget['background'] = button_hover_bg

    def on_leave(e):
        e.widget['background'] = button_bg

    # Créer les boutons
    btn_connexion = tk.Button(menu_frame, text="Connexion", font=("Helvetica", 12), command=open_connexion_window, bg=button_bg, fg=button_fg, relief="flat")
    btn_connexion.pack(pady=10, fill=tk.X, padx=50)
    btn_connexion.bind("<Enter>", on_enter)
    btn_connexion.bind("<Leave>", on_leave)

    btn_inscription = tk.Button(menu_frame, text="Inscription", font=("Helvetica", 12), command=inscription, bg=button_bg, fg=button_fg, relief="flat")
    btn_inscription.pack(pady=10, fill=tk.X, padx=50)
    btn_inscription.bind("<Enter>", on_enter)
    btn_inscription.bind("<Leave>", on_leave)

    btn_modif = tk.Button(menu_frame, text="Modification", font=("Helvetica", 12), command=menu_modif, bg=button_bg, fg=button_fg, relief="flat")
    btn_modif.pack(pady=10, fill=tk.X, padx=50)
    btn_modif.bind("<Enter>", on_enter)
    btn_modif.bind("<Leave>", on_leave)

    btn_quitter = tk.Button(menu_frame, text="Quitter", font=("Helvetica", 12), command=root.quit, bg=button_bg, fg=button_fg, relief="flat")
    btn_quitter.pack(pady=30, fill=tk.X, padx=50)
    btn_quitter.bind("<Enter>", on_enter)
    btn_quitter.bind("<Leave>", on_leave)

    root.mainloop()






menu_gui()